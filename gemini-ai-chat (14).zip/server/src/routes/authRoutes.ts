import express, { Request as ExpressRequest, Response as ExpressResponse } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { getDb } from '../db';
import { protect } from '../auth';
import { config } from '../config';
import { OAuth2Client } from 'google-auth-library';
import TelegramBot from 'node-telegram-bot-api';
import { User, Message } from '../types';
import { Server as SocketIOServer } from 'socket.io';
import '../types'; // Import for declaration merging
import { getIo } from '../websocketStore';
import { CHAT_CONTACT_USER_FIELDS } from '../sharedConstants';
import { push } from '../push'; // Import push for notifications
import { verifyTelegramWebAppData } from '../utils/telegramAuth';

const router = express.Router();
let googleClient: OAuth2Client | null = null;
export let bot: TelegramBot | null = null;

const TELEGRAM_BOT_TOKEN = config.TELEGRAM_BOT_TOKEN;
const GOOGLE_CLIENT_ID = config.GOOGLE_CLIENT_ID;

// In-memory store for phone verification codes.
const phoneCodeStore: Record<string, { code: string; expires: number; verified?: boolean }> = {};
// In-memory store for two-factor authentication codes.
const twoFactorCodeStore: Record<string, { code: string; expires: number }> = {};


// In-memory store for users who are currently replying via Telegram
const replyContextCache = new Map<number, { chatId: string }>();

const initializeBotListeners = () => {
    if (!bot) return;

    // Handler for the /start command to send a magic login link
    bot.onText(/\/start/, async (msg) => {
        const telegramId = msg.chat.id.toString();
        const db = getDb();
        const user = await db.get('SELECT * FROM users WHERE telegram_id = ?', telegramId);
        if (user && msg.from) {
            const token = crypto.randomBytes(20).toString('hex');
            const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 min expiry
            await db.run('INSERT INTO magic_links (token, userId, expiresAt) VALUES (?, ?, ?)', [token, user.id, expiresAt]);
            
            // This URL needs to match the frontend route
            const loginUrl = `https://bulkhead.hopto.org/auth/magic/${token}`;
            
            await bot.sendMessage(telegramId, `Welcome back, ${user.name}!\nClick the link to log in to the web messenger:\n${loginUrl}`);
        } else {
            await bot.sendMessage(telegramId, "Your Telegram account is not linked. Please log in via the web app first and link your account in your profile settings.");
        }
    });

    // Handler for the "Reply" button callback
    bot.on('callback_query', async (callbackQuery) => {
        if (!bot) return;
        const msg = callbackQuery.message;
        const data = callbackQuery.data;

        if (msg && data && data.startsWith('reply_')) {
            const chatId = data.split('_')[1];
            const telegramId = msg.chat.id;

            replyContextCache.set(telegramId, { chatId });
            await bot.sendMessage(telegramId, `Replying to chat. Send your message now. (To cancel, send /cancel)`);
            await bot.answerCallbackQuery(callbackQuery.id);
        }
    });

    // Handler for text messages, checks for reply context
    bot.on('message', async (msg) => {
        // Ignore commands
        if (msg.text?.startsWith('/')) return;

        const telegramId = msg.chat.id;
        const replyContext = replyContextCache.get(telegramId);
        
        if (replyContext) {
            const { chatId } = replyContext;
            const db = getDb();
            const sender = await db.get<User>('SELECT * FROM users WHERE telegram_id = ?', telegramId.toString());

            if (sender && msg.text) {
                const io = getIo();
                
                // Construct and save the message as if it came from the web app
                const newMessage: Message = {
                    id: crypto.randomUUID(),
                    chatId,
                    senderId: sender.id,
                    content: msg.text,
                    timestamp: new Date().toISOString(),
                    type: 'text',
                    isEdited: false,
                    isDeleted: false,
                    reactions: {},
                };

                await db.run(
                    'INSERT INTO messages (id, chatId, senderId, content, timestamp, type) VALUES (?, ?, ?, ?, ?, ?)',
                    [newMessage.id, newMessage.chatId, newMessage.senderId, newMessage.content, newMessage.timestamp, 'text']
                );
                
                // Emit to the chat room via WebSocket
                const senderInfo = await db.get<User>(`SELECT ${CHAT_CONTACT_USER_FIELDS} FROM users WHERE id = ?`, sender.id);
                const payload = { ...newMessage, sender: senderInfo };
                io.to(chatId).emit('newMessage', payload);
                
                // Also notify the other user in the private chat for sidebar updates
                const partnerId = chatId.split('-').find(id => id !== sender.id);
                if (partnerId) {
                    io.to(partnerId).emit('newMessage', payload);
                }

                await bot.sendMessage(telegramId, `✅ Message sent!`);
            }
            
            replyContextCache.delete(telegramId);
        }
    });
    
    // Handler for cancelling a reply
    bot.onText(/\/cancel/, (msg) => {
        const telegramId = msg.chat.id;
        if (replyContextCache.has(telegramId)) {
            replyContextCache.delete(telegramId);
            bot?.sendMessage(telegramId, 'Reply cancelled.');
        }
    });
};

export const initializeAuthServices = (socketIo: SocketIOServer) => {
    // Initialize Google Client
    if (GOOGLE_CLIENT_ID) {
        googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);
        console.log("✅ Google Auth Client initialized.");
    } else {
        console.warn("⚠️  WARNING: GOOGLE_CLIENT_ID not found in config.ts. Google Login will be disabled.");
    }
    
    // Initialize Telegram Bot
    try {
        if (TELEGRAM_BOT_TOKEN && TELEGRAM_BOT_TOKEN.length > 20) {
            if (bot) {
                console.log("Stopping existing Telegram Bot polling to re-initialize...");
                bot.stopPolling({ cancel: true }); 
            }
            bot = new TelegramBot(TELEGRAM_BOT_TOKEN, { polling: true });
            
            bot.removeAllListeners();

            console.log("✅ Telegram Bot initialized successfully with polling.");
            initializeBotListeners();
        } else {
            console.warn("⚠️  WARNING: TELEGRAM_BOT_TOKEN not found or is invalid in config.ts. Telegram features will be disabled.");
        }
    } catch (error: any) {
        console.error("🔴 FAILED to initialize Telegram Bot.", error.message);
        bot = null;
    }
}

const userFieldsToSelect = 'id, username, name, uniqueId, gender, dob, createdAt, telegram_id as telegramId, phone_number as phoneNumber, is_anonymous as isAnonymous, avatar_url as avatarUrl, profile_setup as profileSetup, role, is_banned, ban_reason as banReason, ban_expires_at as banExpiresAt, google_id as googleId, mute_expires_at as muteExpiresAt, mute_reason as muteReason, last_seen as lastSeen, profile_color, message_color, description, profile_emoji, profile_emoji_density, profile_emoji_rotation, privacy_show_phone, privacy_show_telegram, privacy_show_dob, privacy_show_description, privacy_show_last_seen, privacy_show_typing, is_2fa_enabled';

const transformUser = (dbUser: any): User => {
    if (!dbUser) return dbUser;
    const user = {
        ...dbUser,
        telegramId: dbUser.telegram_id || dbUser.telegramId,
        phoneNumber: dbUser.phone_number || dbUser.phoneNumber,
        avatarUrl: dbUser.avatar_url || dbUser.avatarUrl,
        googleId: dbUser.google_id || dbUser.googleId,
        banReason: dbUser.ban_reason || dbUser.banReason,
        banExpiresAt: dbUser.ban_expires_at || dbUser.banExpiresAt,
        muteExpiresAt: dbUser.mute_expires_at || dbUser.muteExpiresAt,
        muteReason: dbUser.mute_reason || dbUser.muteReason,
        lastSeen: dbUser.last_seen || dbUser.lastSeen,
        isAnonymous: !!dbUser.is_anonymous,
        profileSetup: !!dbUser.profile_setup,
        is_banned: !!dbUser.is_banned,
        is_2fa_enabled: !!dbUser.is_2fa_enabled,
        privacy_show_phone: !!dbUser.privacy_show_phone,
        privacy_show_telegram: !!dbUser.privacy_show_telegram,
        privacy_show_dob: !!dbUser.privacy_show_dob,
        privacy_show_description: !!dbUser.privacy_show_description,
        privacy_show_last_seen: !!dbUser.privacy_show_last_seen,
        privacy_show_typing: !!dbUser.privacy_show_typing,
    };
    delete user.password_hash;
    return user as User;
};

const generateToken = (res: ExpressResponse, userId: string) => {
    const token = jwt.sign({ id: userId }, config.JWT_SECRET, { expiresIn: '30d' });
    res.cookie('token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV !== 'development',
        sameSite: 'strict',
        maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    });
};

const send2FACode = async (user: User) => {
    if (!bot || !user.telegram_id) return false;
    const code = crypto.randomInt(100000, 999999).toString();
    twoFactorCodeStore[user.id] = { code, expires: Date.now() + 10 * 60 * 1000 }; // 10 min expiry
    try {
        await bot.sendMessage(user.telegram_id, `Your login verification code is: ${code}`);
        return true;
    } catch (e) {
        console.error("Failed to send 2FA code via Telegram:", e);
        return false;
    }
};

// --- ROUTES ---

router.post('/register', async (req: ExpressRequest, res: ExpressResponse) => {
    const { username, password, name } = req.body;
    if (!username || !password || !name) {
        return res.status(400).json({ message: 'Please provide username, password, and name.' });
    }
    const db = getDb();
    try {
        const existingUser = await db.get('SELECT id FROM users WHERE username = ? AND is_anonymous = 0', username);
        if (existingUser) {
            return res.status(409).json({ message: 'This name is taken by a registered user.' });
        }

        const salt = await bcrypt.genSalt(10);
        const passwordHash = await bcrypt.hash(password, salt);
        const userId = `user_${crypto.randomBytes(8).toString('hex')}`;
        const uniqueId = username.toLowerCase() + Math.random().toString(36).substring(2, 6);

        await db.run(
            'INSERT INTO users (id, username, password_hash, name, uniqueId, createdAt) VALUES (?, ?, ?, ?, ?, ?)',
            [userId, username, passwordHash, name, uniqueId, new Date().toISOString()]
        );
        
        generateToken(res, userId);
        const newUser = await db.get(`SELECT ${userFieldsToSelect} FROM users WHERE id = ?`, userId);
        res.status(201).json(transformUser(newUser));
    } catch (error) {
        res.status(500).json({ message: 'Server error during registration.' });
    }
});

router.post('/login', async (req: ExpressRequest, res: ExpressResponse) => {
    const { username, password } = req.body;
    const db = getDb();
    try {
        const user = await db.get('SELECT * FROM users WHERE username = ? AND is_anonymous = 0', username);
        if (!user || !user.password_hash) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }
        
        if (user.is_2fa_enabled) {
            const sent = await send2FACode(user);
            if (sent) {
                return res.status(202).json({ twoFactorRequired: true, userId: user.id });
            } else {
                return res.status(500).json({ message: "Failed to send 2FA code. Please try again."});
            }
        }
        
        generateToken(res, user.id);
        res.json(transformUser(user));
    } catch (error) {
        res.status(500).json({ message: 'Server error during login.' });
    }
});

router.post('/anonymous-login', async (req: ExpressRequest, res: ExpressResponse) => {
    const { username } = req.body;
    if (!username) {
        return res.status(400).json({ message: 'Please provide a username.' });
    }
    const db = getDb();
    try {
        const existingUser = await db.get('SELECT id FROM users WHERE username = ? AND is_anonymous = 0', username);
        if (existingUser) {
            return res.status(409).json({ message: 'This name is taken by a registered user.' });
        }
        const userId = `guest_${crypto.randomBytes(8).toString('hex')}`;
        const uniqueId = `guest_${Math.random().toString(36).substring(2, 8)}`;

        await db.run(
            'INSERT INTO users (id, username, name, uniqueId, createdAt, is_anonymous) VALUES (?, ?, ?, ?, ?, 1)',
            [userId, username, username, uniqueId, new Date().toISOString()]
        );
        
        generateToken(res, userId);
        const newUser = await db.get(`SELECT ${userFieldsToSelect} FROM users WHERE id = ?`, userId);
        res.status(201).json(transformUser(newUser));
    } catch (error) {
        res.status(500).json({ message: 'Server error during guest login.' });
    }
});

router.get('/me', protect, async (req: ExpressRequest, res: ExpressResponse) => {
    const db = getDb();
    try {
        const user = await db.get(`SELECT ${userFieldsToSelect} FROM users WHERE id = ?`, req.user!.id);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.json(transformUser(user));
    } catch (error) {
        res.status(500).json({ message: 'Server error fetching user profile.' });
    }
});

router.post('/logout', (req: ExpressRequest, res: ExpressResponse) => {
    res.cookie('token', '', { httpOnly: true, expires: new Date(0) });
    res.status(200).json({ message: 'Logged out successfully' });
});

router.post('/google', async (req: ExpressRequest, res: ExpressResponse) => {
    if (!googleClient) {
        return res.status(503).json({ message: 'Google Sign-In is not configured on the server.' });
    }
    const { credential } = req.body;
    try {
        const ticket = await googleClient.verifyIdToken({
            idToken: credential,
            audience: GOOGLE_CLIENT_ID,
        });
        const payload = ticket.getPayload();
        if (!payload || !payload.sub || !payload.email) {
            return res.status(400).json({ message: 'Invalid Google token.' });
        }

        const db = getDb();
        let user = await db.get('SELECT * FROM users WHERE google_id = ?', payload.sub);

        if (!user) {
            const userId = `user_${crypto.randomBytes(8).toString('hex')}`;
            const name = payload.name || payload.email.split('@')[0];
            const uniqueId = name.toLowerCase().replace(/\s/g, '') + Math.random().toString(36).substring(2, 6);
            await db.run(
                'INSERT INTO users (id, username, name, uniqueId, google_id, avatar_url, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [userId, payload.email, name, uniqueId, payload.sub, payload.picture, new Date().toISOString()]
            );
            user = await db.get('SELECT * FROM users WHERE id = ?', userId);
        }
        
        if (user.is_2fa_enabled) {
            await send2FACode(user);
            return res.status(202).json({ twoFactorRequired: true, userId: user.id });
        }

        generateToken(res, user.id);
        res.json(transformUser(user));
    } catch (error) {
        res.status(500).json({ message: 'Google Sign-In failed.' });
    }
});

router.post('/magic-link-login', async (req, res) => {
    const { token } = req.body;
    const db = getDb();
    try {
        const link = await db.get('SELECT * FROM magic_links WHERE token = ?', token);
        if (!link || new Date(link.expiresAt) < new Date()) {
            return res.status(401).json({ message: 'Invalid or expired login link.' });
        }

        await db.run('DELETE FROM magic_links WHERE token = ?', token);
        
        const user = await db.get(`SELECT ${userFieldsToSelect} FROM users WHERE id = ?`, link.userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found.' });
        }
        
        generateToken(res, user.id);
        res.json(transformUser(user));
    } catch (error) {
        res.status(500).json({ message: 'Server error during magic link login.' });
    }
});

router.post('/2fa/login-verify', async (req, res) => {
    const { userId, code } = req.body;
    const stored = twoFactorCodeStore[userId];

    if (!stored || stored.code !== code || stored.expires < Date.now()) {
        return res.status(401).json({ message: 'Invalid or expired verification code.' });
    }
    
    delete twoFactorCodeStore[userId];
    
    const db = getDb();
    const user = await db.get(`SELECT ${userFieldsToSelect} FROM users WHERE id = ?`, userId);
    if (!user) return res.status(404).json({ message: 'User not found.' });

    generateToken(res, user.id);
    res.json(transformUser(user));
});

router.post('/2fa/enable-request', protect, async (req, res) => {
    if (!bot) return res.status(503).json({ message: 'Telegram integration is not configured.' });
    const userId = req.user!.id;
    // The client sends the full Telegram auth object
    const { id: telegramId, first_name, username } = req.body;
    
    if (!telegramId) return res.status(400).json({ message: 'Invalid Telegram data.' });

    const db = getDb();
    try {
        await db.run('UPDATE users SET telegram_id = ? WHERE id = ?', [telegramId.toString(), userId]);
        
        const code = crypto.randomInt(100000, 999999).toString();
        twoFactorCodeStore[telegramId.toString()] = { code, expires: Date.now() + 10 * 60 * 1000 };
        
        await bot.sendMessage(telegramId, `Your 2FA verification code is: ${code}`);

        res.json({ message: 'Verification code sent.', telegramId: telegramId.toString() });
    } catch (error) {
        res.status(500).json({ message: 'Failed to initiate 2FA setup.' });
    }
});

router.post('/2fa/enable-verify', protect, async (req, res) => {
    const userId = req.user!.id;
    const { code, telegramId } = req.body;
    const stored = twoFactorCodeStore[telegramId];

    if (!stored || stored.code !== code || stored.expires < Date.now()) {
        return res.status(401).json({ message: 'Invalid or expired verification code.' });
    }
    
    const db = getDb();
    await db.run('UPDATE users SET is_2fa_enabled = 1 WHERE id = ?', [userId]);

    delete twoFactorCodeStore[telegramId];
    res.json({ message: '2FA enabled successfully.' });
});

router.post('/2fa/disable', protect, async (req, res) => {
    const userId = req.user!.id;
    const db = getDb();
    await db.run('UPDATE users SET is_2fa_enabled = 0 WHERE id = ?', [userId]);
    res.json({ message: '2FA disabled successfully.' });
});

router.post('/telegram-webapp-login', async (req, res) => {
    const { initData } = req.body;
    const userData = verifyTelegramWebAppData(initData);

    if (!userData) {
        return res.status(401).json({ message: 'Invalid Telegram data.' });
    }
    
    const db = getDb();
    try {
        let user = await db.get('SELECT * FROM users WHERE telegram_id = ?', userData.id.toString());
        if (!user) {
            const userId = `user_tg_${userData.id}`;
            const uniqueId = userData.username || `tg${userData.id}`;
            await db.run(
                'INSERT INTO users (id, username, name, uniqueId, telegram_id, avatar_url, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [userId, uniqueId, userData.first_name, uniqueId, userData.id.toString(), userData.photo_url, new Date().toISOString()]
            );
            user = await db.get('SELECT * FROM users WHERE id = ?', userId);
        }
        
        if (user.is_2fa_enabled) {
            await send2FACode(user);
            return res.status(202).json({ twoFactorRequired: true, userId: user.id });
        }
        
        generateToken(res, user.id);
        res.json(transformUser(user));
    } catch (error) {
        res.status(500).json({ message: 'Server error during Telegram Web App login.' });
    }
});


export default router;