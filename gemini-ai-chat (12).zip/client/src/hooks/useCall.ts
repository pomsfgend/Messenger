import { useState, useRef, useEffect } from 'react';
import { socket } from '../utils/socket';
import { processEncodedStream } from '../utils/audioProcessor';

export const useCall = () => {
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [callStatus, setCallStatus] = useState<'idle' | 'calling' | 'in-call' | 'failed'>('idle');
  const [currentCallPeerId, setCurrentCallPeerId] = useState<string | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const processingRef = useRef<{ [kind: string]: boolean }>({});

  useEffect(() => {
    const handleOffer = async (data: { from: string; offer: RTCSessionDescriptionInit }) => {
      setCurrentCallPeerId(data.from);
      setCallStatus('calling');
    };

    const handleAnswer = async (data: { from: string; answer: RTCSessionDescriptionInit }) => {
      if (pcRef.current && pcRef.current.signalingState !== 'stable') {
        await pcRef.current.setRemoteDescription(new RTCSessionDescription(data.answer));
      }
    };

    const handleIceCandidate = (data: { from: string; candidate: RTCIceCandidate }) => {
      if (pcRef.current && data.candidate) {
        pcRef.current.addIceCandidate(new RTCIceCandidate(data.candidate)).catch(console.error);
      }
    };

    const handleEndCall = () => {
      endCall();
    };

    socket.on('call:offer', handleOffer);
    socket.on('call:answer', handleAnswer);
    socket.on('call:ice-candidate', handleIceCandidate);
    socket.on('call:end', handleEndCall);

    return () => {
      socket.off('call:offer', handleOffer);
      socket.off('call:answer', handleAnswer);
      socket.off('call:ice-candidate', handleIceCandidate);
      socket.off('call:end', handleEndCall);
    };
  }, []);

  const startCall = async (isVideo: boolean) => {
    setCallStatus('calling');
    try {
      // Получение ICE-серверов
      const iceResponse = await fetch('/api/getIceServers');
      const iceServers = await iceResponse.json();

      const pc = new RTCPeerConnection({
        iceServers: iceServers,
        iceTransportPolicy: 'all'
      });
      pcRef.current = pc;

      // Получение локального медиапотока
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: isVideo
      });
      setLocalStream(stream);

      // Добавление треков и создание потоков ДО установки соединения
      stream.getTracks().forEach(track => {
        const sender = pc.addTrack(track, stream);
        
        // КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ: создание потоков сразу после добавления трека
        if (!processingRef.current[track.kind]) {
          try {
            // Проверка поддержки метода
            if ('createEncodedStreams' in RTCRtpSender.prototype) {
              const { readable, writable } = sender.createEncodedStreams();
              processEncodedStream(track.kind, readable, writable);
              processingRef.current[track.kind] = true;
            }
          } catch (e) {
            console.warn(`Error creating encoded streams for ${track.kind}:`, e);
          }
        }
      });

      // Обработчик для удалённых треков
      pc.ontrack = (event) => {
        if (event.streams && event.streams[0]) {
          setRemoteStream(event.streams[0]);
        }
      };

      // Обработчики ICE-кандидатов
      pc.onicecandidate = (event) => {
        if (event.candidate && currentCallPeerId) {
          socket.emit('call:ice-candidate', {
            to: currentCallPeerId,
            candidate: event.candidate
          });
        }
      };

      pc.oniceconnectionstatechange = () => {
        if (pc.iceConnectionState === 'disconnected' || pc.iceConnectionState === 'failed') {
          endCall();
        }
      };

      // Создание предложения ПОСЛЕ инициализации потоков
      const offer = await pc.createOffer({
        offerToReceiveAudio: true,
        offerToReceiveVideo: true
      });
      
      await pc.setLocalDescription(offer);

      // Отправка предложения
      if (currentCallPeerId) {
        socket.emit('call:offer', {
          offer: offer,
          to: currentCallPeerId
        });
      }

      setCallStatus('in-call');
    } catch (err) {
      console.error("Failed to start call:", err);
      setCallStatus('failed');
    }
  };

  const answerCall = async () => {
    if (!pcRef.current || !currentCallPeerId) return;
    
    try {
      const pc = pcRef.current;
      
      // Создание ответа
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      
      // Отправка ответа
      socket.emit('call:answer', {
        answer: answer,
        to: currentCallPeerId
      });
      
      setCallStatus('in-call');
    } catch (err) {
      console.error("Failed to answer call:", err);
      setCallStatus('failed');
    }
  };

  const endCall = () => {
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }
    
    setRemoteStream(null);
    setCallStatus('idle');
    setCurrentCallPeerId(null);
    
    if (currentCallPeerId) {
      socket.emit('call:end', { to: currentCallPeerId });
    }
    
    // Сброс флагов обработки
    processingRef.current = {};
  };

  return {
    localStream,
    remoteStream,
    callStatus,
    startCall,
    endCall,
    answerCall,
    setCurrentCallPeerId
  };
};