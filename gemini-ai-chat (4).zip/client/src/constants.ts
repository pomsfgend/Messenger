
export const GLOBAL_CHAT_ID = 'global';