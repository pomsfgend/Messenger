import express, { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { getDb } from '../db';
import { protect } from '../auth';
import { config } from '../config';
import { OAuth2Client } from 'google-auth-library';
import TelegramBot from 'node-telegram-bot-api';
import { User, Message } from '../types';
import { Server as SocketIOServer } from 'socket.io';
import '../types'; // Import for declaration merging
import { getIo } from '../websocketStore';
import { CHAT_CONTACT_USER_FIELDS } from '../sharedConstants';
import { push } from '../push'; // Import push for notifications
import { verifyTelegramWebAppData } from '../utils/telegramAuth';

const router = express.Router();
let googleClient: OAuth2Client | null = null;
export let bot: TelegramBot | null = null;

const TELEGRAM_BOT_TOKEN = config.TELEGRAM_BOT_TOKEN;
const TELEGRAM_GATEWAY_TOKEN = config.TELEGRAM_GATEWAY_TOKEN;
const GOOGLE_CLIENT_ID = config.GOOGLE_CLIENT_ID;

// In-memory store for phone verification codes.
const phoneCodeStore: Record<string, { code: string; expires: number; verified?: boolean }> = {};
// In-memory store for two-factor authentication codes.
const twoFactorCodeStore: Record<string, { code: string; expires: number }> = {};


// In-memory store for users who are currently replying via Telegram
const replyContextCache = new Map<number, { chatId: string }>();

const initializeBotListeners = () => {
    if (!bot) return;

    // Handler for the /start command to send a magic login link
    bot.onText(/\/start/, async (msg) => {
        const telegramId = msg.chat.id.toString();
        const db = getDb();
        const user = await db.get('SELECT * FROM users WHERE telegram_id = ?', telegramId);
        if (user && msg.from) {
            const token = crypto.randomBytes(20).toString('hex');
            const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 min expiry
            await db.run('INSERT INTO magic_links (token, userId, expiresAt) VALUES (?, ?, ?)', [token, user.id, expiresAt]);
            
            // This URL needs to match the frontend route
            const loginUrl = `https://bulkhead.hopto.org/auth/magic/${token}`;
            
            await bot.sendMessage(telegramId, `Welcome back, ${user.name}!\nClick the link to log in to the web messenger:\n${loginUrl}`);
        } else {
            await bot.sendMessage(telegramId, "Your Telegram account is not linked. Please log in via the web app first and link your account in your profile settings.");
        }
    });

    // Handler for the "Reply" button callback
    bot.on('callback_query', async (callbackQuery) => {
        if (!bot) return;
        const msg = callbackQuery.message;
        const data = callbackQuery.data;

        if (msg && data && data.startsWith('reply_')) {
            const chatId = data.split('_')[1];
            const telegramId = msg.chat.id;

            replyContextCache.set(telegramId, { chatId });
            await bot.sendMessage(telegramId, `Replying to chat. Send your message now. (To cancel, send /cancel)`);
            await bot.answerCallbackQuery(callbackQuery.id);
        }
    });

    // Handler for text messages, checks for reply context
    bot.on('message', async (msg) => {
        // Ignore commands
        if (msg.text?.startsWith('/')) return;

        const telegramId = msg.chat.id;
        const replyContext = replyContextCache.get(telegramId);
        
        if (replyContext) {
            const { chatId } = replyContext;
            const db = getDb();
            const sender = await db.get<User>('SELECT * FROM users WHERE telegram_id = ?', telegramId.toString());

            if (sender && msg.text) {
                const io = getIo();
                
                // Construct and save the message as if it came from the web app
                const newMessage: Message = {
                    id: crypto.randomUUID(),
                    chatId,
                    senderId: sender.id,
                    content: msg.text,
                    timestamp: new Date().toISOString(),
                    type: 'text',
                    isEdited: false,
                    isDeleted: false,
                    reactions: {},
                };

                await db.run(
                    'INSERT INTO messages (id, chatId, senderId, content, timestamp, type) VALUES (?, ?, ?, ?, ?, ?)',
                    [newMessage.id, newMessage.chatId, newMessage.senderId, newMessage.content, newMessage.timestamp, 'text']
                );
                
                // Emit to the chat room via WebSocket
                const senderInfo = await db.get<User>(`SELECT ${CHAT_CONTACT_USER_FIELDS} FROM users WHERE id = ?`, sender.id);
                const payload = { ...newMessage, sender: senderInfo };
                io.to(chatId).emit('newMessage', payload);
                
                // Also notify the other user in the private chat for sidebar updates
                const partnerId = chatId.split('-').find(id => id !== sender.id);
                if (partnerId) {
                    io.to(partnerId).emit('newMessage', payload);
                }

                await bot.sendMessage(telegramId, `✅ Message sent!`);
            }
            
            replyContextCache.delete(telegramId);
        }
    });
    
    // Handler for cancelling a reply
    bot.onText(/\/cancel/, (msg) => {
        const telegramId = msg.chat.id;
        if (replyContextCache.has(telegramId)) {
            replyContextCache.delete(telegramId);
            bot?.sendMessage(telegramId, 'Reply cancelled.');
        }
    });
};

export const initializeAuthServices = (socketIo: SocketIOServer) => {
    // Initialize Google Client
    if (GOOGLE_CLIENT_ID) {
        googleClient = new OAuth2Client(GOOGLE_CLIENT_ID);
        console.log("✅ Google Auth Client initialized.");
    } else {
        console.warn("⚠️  WARNING: GOOGLE_CLIENT_ID not found in config.ts. Google Login will be disabled.");
    }
    
    // Initialize Telegram Bot
    try {
        if (TELEGRAM_BOT_TOKEN && TELEGRAM_BOT_TOKEN.length > 20) {
            if (bot) {
                console.log("Stopping existing Telegram Bot polling to re-initialize...");
                bot.stopPolling({ cancel: true }); 
            }
            bot = new TelegramBot(TELEGRAM_BOT_TOKEN, { polling: true });
            
            bot.removeAllListeners();

            console.log("✅ Telegram Bot initialized successfully with polling.");
            initializeBotListeners();
        } else {
            console.warn("⚠️  WARNING: TELEGRAM_BOT_TOKEN not found or is invalid in config.ts. Telegram features will be disabled.");
        }
    } catch (error: any) {
        console.error("🔴 FAILED to initialize Telegram Bot.", error.message);
        bot = null;
    }
}


const userFieldsToSelect = 'id, username, name, uniqueId, gender, dob, createdAt, telegram_id as telegramId, phone_number as phoneNumber, is_anonymous as isAnonymous, avatar_url as avatarUrl, profile_setup as profileSetup, role, is_banned, ban_reason as banReason, ban_expires_at as banExpiresAt, google_id as googleId, mute_expires_at as muteExpiresAt, mute_reason as muteReason, last_seen as lastSeen, profile_color, message_color, description, profile_emoji, profile_emoji_density, profile_emoji_rotation, privacy_show_phone, privacy_show_telegram, privacy_show_dob, privacy_show_description, privacy_show_last_seen, privacy_show_typing, is_2fa_enabled';

const transformUser = (dbUser: any): User => {
    if (!dbUser) return dbUser;
    // This function robustly handles both snake_case from the DB
    // and camelCase from aliased queries, ensuring consistent object shape.
    const user = {
        ...dbUser, // Keep any other fields, like password_hash
        telegramId: dbUser.telegram_id || dbUser.telegramId,
        phoneNumber: dbUser.phone_number || dbUser.phoneNumber,
        avatarUrl: dbUser.avatar_url || dbUser.avatarUrl,
        googleId: dbUser.google_id || dbUser.googleId,
        banReason: dbUser.ban_reason || dbUser.banReason,
        banExpiresAt: dbUser.ban_expires_at || dbUser.banExpiresAt,
        muteExpiresAt: dbUser.mute_expires_at || dbUser.muteExpiresAt,
        muteReason: dbUser.mute_reason || dbUser.muteReason,
        lastSeen: dbUser.last_seen || dbUser.lastSeen,
        isAnonymous: !!dbUser.is_anonymous,
        profileSetup: !!dbUser.profile_setup,
        is_banned: !!dbUser.is_banned,
        is_2fa_enabled: !!dbUser.is_2fa_enabled,
        privacy_show_phone: !!dbUser.privacy_show_phone,
        privacy_show_telegram: !!dbUser.privacy_show
export default router;