// WARNING: Hardcoding configuration is not recommended for production environments.
// This is done to simplify setup as requested by the user.

export const clientConfig = {
    GOOGLE_CLIENT_ID: "329920739796-t5ql5j0mgcjoq3at9hk7umh3efjoib35.apps.googleusercontent.com",
    TELEGRAM_BOT_USERNAME: "authorizerprogaming_bot",
};
