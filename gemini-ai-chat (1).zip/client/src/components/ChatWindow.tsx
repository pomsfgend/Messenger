import React, { useState, useEffect, useRef, useCallback, useLayoutEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import * as api from '../services/api';
import type { Message, User, MessageType, ReactionMap, ChatContact } from '../types';
import toast from 'react-hot-toast';
import { useI18n } from '../hooks/useI18n';
import { useSocket } from '../hooks/useSocket';
import { GLOBAL_CHAT_ID } from '../constants';
import Avatar from './Avatar';
import ViewProfileModal from './ViewProfileModal';
import MediaUploadPreviewModal from './MediaUploadPreviewModal';
import MessageContextMenu, { Action } from './MessageContextMenu';
import { useNavigate } from 'react-router-dom';
import MediaViewerModal from './MediaViewerModal';
import useAutosizeTextArea from '../hooks/useAutosizeTextArea';
import GlobalChatInfoModal from './GlobalChatInfoModal';
import { motion, AnimatePresence } from 'framer-motion';
import ConfirmationModal from './ConfirmationModal';
import MessageBubble from './MessageBubble';
import EmojiPicker, { EmojiClickData, Theme } from 'emoji-picker-react';
import { useTheme } from '../hooks/useTheme';
import VideoRecorderModal from './VideoRecorderModal';
import { processVideoCircleForDownload } from '../utils/mediaProcessor';
import { FaVideo, FaMicrophone, FaMicrophoneSlash, FaVideoSlash, FaPhoneSlash } from 'react-icons/fa';
import { useCall } from '../hooks/useCall';
import IncomingCallToast from './IncomingCallToast';
import { isMobile } from 'react-device-detect';


const AudioRecorder: React.FC<{ onSend: (file: File) => void; onCancel: () => void; }> = ({ onSend, onCancel }) => {
    const { t } = useI18n();
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const [recordingTime, setRecordingTime] = useState(0);
    const recordingIntervalRef = useRef<number | null>(null);
    const isCancelledRef = useRef(false);

    const cleanup = useCallback(() => {
        if (recordingIntervalRef.current) {
            clearInterval(recordingIntervalRef.current);
            recordingIntervalRef.current = null;
        }
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
            try { mediaRecorderRef.current.stop(); } catch(e) {}
        }
    }, []);
    
    useEffect(() => {
        let isMounted = true;
        isCancelledRef.current = false;
        
        const startRecording = async () => {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                if (!isMounted) {
                    stream.getTracks().forEach(t => t.stop());
                    return;
                }
                streamRef.current = stream;
                
                const options = { mimeType: 'audio/webm;codecs=opus' };
                if (!MediaRecorder.isTypeSupported(options.mimeType)) {
                    toast.error(t('toast.unsupportedFileType'));
                    onCancel(); return;
                }

                mediaRecorderRef.current = new MediaRecorder(stream, options);
                const chunks: BlobPart[] = [];
                mediaRecorderRef.current.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
                mediaRecorderRef.current.onstop = () => {
                     streamRef.current?.getTracks().forEach(track => track.stop());
                     if (isCancelledRef.current) {
                         onCancel(); return;
                     }
                     const blob = new Blob(chunks, { type: options.mimeType });
                     if (blob.size > 256) {
                         const file = new File([blob], `voice-${Date.now()}.webm`, { type: options.mimeType });
                         onSend(file);
                     } else {
                         toast.error(t('toast.emptyFileError'));
                         onCancel();
                     }
                };
                mediaRecorderRef.current.start();
                setRecordingTime(0);
                recordingIntervalRef.current = window.setInterval(() => setRecordingTime(prev => prev + 1), 1000);
            } catch (err) {
                toast.error(t('toast.micDenied'));
                onCancel();
            }
        };
        startRecording();
        return () => { isMounted = false; cleanup(); };
    }, [onSend, onCancel, t, cleanup]);

    const handleSend = () => {
        isCancelledRef.current = false;
        cleanup();
    };

    const handleCancel = () => {
        isCancelledRef.current = true;
        cleanup();
    };


    return (
        <div className="w-full flex items-center justify-between px-4 animate-fade-in">
            <button onClick={handleCancel} className="p-3 text-red-500 rounded-full hover:bg-red-500/10 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" /></svg>
            </button>
            <div className="flex items-center gap-2 text-red-500">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span className="font-mono">{new Date(recordingTime * 1000).toISOString().substr(14, 5)}</span>
            </div>
            <button onClick={handleSend} className="w-12 h-12 flex items-center justify-center bg-indigo-500 rounded-full text-white flex-shrink-0">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg>
            </button>
        </div>
    );
};

const formatLastSeen = (lastSeen: string | null | undefined, t: (key: string, options?: any) => string): string => {
    // FIX: Correctly handle 'recent' status from server privacy filter
    if (lastSeen === 'recent') return t('chat.lastSeenRecent');
    if (!lastSeen) return t('chat.online');
    
    const now = new Date();
    const lastSeenDate = new Date(lastSeen);
    const diffSeconds = Math.round((now.getTime() - lastSeenDate.getTime()) / 1000);

    if (diffSeconds < 60) return t('time.justNow');
    if (diffSeconds < 3600) return t('time.minutesAgo', { count: Math.floor(diffSeconds / 60) });
    if (diffSeconds < 86400) return t('time.hoursAgo', { count: Math.floor(diffSeconds / 3600) });
    
    // For dates older than a day, show date and time
    return `${t('chat.lastSeen')} ${lastSeenDate.toLocaleString()}`;
};


const ChatWindow: React.FC<{
  chatId?: string;
  onToggleSidebar: () => void;
  isStandalone?: boolean;
}> = ({ chatId, onToggleSidebar, isStandalone = false }) => {
    const { currentUser } = useAuth();
    const { socket } = useSocket();
    const { t } = useI18n();
    const { mode } = useTheme();
    const navigate = useNavigate();

    const [messages, setMessages] = useState<Message[]>([]);
    const [chatUsers, setChatUsers] = useState<Record<string, User>>({});
    const [partner, setPartner] = useState<ChatContact | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [newMessage, setNewMessage] = useState('');
    const [hasMore, setHasMore] = useState(true);
    
    const isFetchingMoreRef = useRef(false);
    const scrollStateRef = useRef({ shouldPreserve: false, oldScrollHeight: 0 });
    const wasAtBottomRef = useRef(true);
    
    const [viewingProfile, setViewingProfile] = useState<User | null>(null);
    const [isChatInfoModalOpen, setIsChatInfoModalOpen] = useState(false);
    
    const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set());
    const typingTimeoutRef = useRef<number | null>(null);
    
    const [mediaPreview, setMediaPreview] = useState<{ file: File; type: MessageType } | null>(null);
    const [isRecordingVideo, setIsRecordingVideo] = useState(false);
    const [isRecordingAudio, setIsRecordingAudio] = useState(false);
    const [uploadingFiles, setUploadingFiles] = useState<Record<string, { progress: number; cancel: () => void; }>>({});

    const [contextMenu, setContextMenu] = useState<{ x: number, y: number, message: Message } | null>(null);
    const [mediaViewerState, setMediaViewerState] = useState<{ items: Message[], startIndex: number } | null>(null);
    
    const [selectionMode, setSelectionMode] = useState(false);
    const [selectedMessages, setSelectedMessages] = useState<Set<string>>(new Set());
    const [isDeleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
    
    const [editingMessage, setEditingMessage] = useState<Message | null>(null);
    const [isReacting, setIsReacting] = useState<string | null>(null);
    
    const [isMuted, setIsMuted] = useState(false);
    const [temporarilyDeleted, setTemporarilyDeleted] = useState<Set<string>>(new Set());
    
    const fileInputRef = useRef<HTMLInputElement>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const chatContainerRef = useRef<HTMLDivElement>(null);
    const contextMenuRef = useRef<HTMLDivElement>(null);
    const textAreaRef = useRef<HTMLTextAreaElement>(null);
    const localVideoRef = useRef<HTMLVideoElement>(null);
    const remoteVideoRef = useRef<HTMLVideoElement>(null);

    const hasScrolledInitially = useRef(false);
    useAutosizeTextArea(textAreaRef.current, newMessage);
    
    const messagesRef = useRef(messages);
    useEffect(() => {
        messagesRef.current = messages;
    }, [messages]);

    const call = useCall({
        localVideoRef,
        remoteVideoRef,
        chatId: chatId || null
    });
    
    useEffect(() => {
        if (call.incomingCall) {
            IncomingCallToast({
                caller: call.incomingCall.caller,
                onAccept: call.acceptCall,
                onReject: call.rejectCall,
            });
        }
    }, [call.incomingCall, call.acceptCall, call.rejectCall]);


    
    const resetState = useCallback(() => {
        setMessages([]);
        setChatUsers({});
        setPartner(null);
        setIsLoading(true);
        setError(null);
        setNewMessage('');
        setHasMore(true);
        setTypingUsers(new Set());
        setSelectionMode(false);
        setSelectedMessages(new Set());
        setEditingMessage(null);
        hasScrolledInitially.current = false;
        wasAtBottomRef.current = true;
    }, []);

    const fetchMessages = useCallback(async (isInitial = false) => {
        if (!chatId || (!isInitial && isFetchingMoreRef.current)) return;
        
        isFetchingMoreRef.current = true;
        if (isInitial) setIsLoading(true);
        
        try {
            const currentMessages = messagesRef.current;
            const before = isInitial || currentMessages.length === 0 ? undefined : currentMessages[0].timestamp;
            const { messages: newMessages, users, hasMore: newHasMore } = await api.getMessages(chatId, 50, before);
            
            setChatUsers(prev => ({ ...prev, ...users }));
            setMessages(prev => isInitial ? newMessages : [...newMessages, ...prev]);
            setHasMore(newHasMore);
            
            if (isInitial) {
                const partnerId = chatId !== GLOBAL_CHAT_ID ? chatId.split('-').find(id => id !== currentUser!.id) : undefined;
                if (partnerId && users[partnerId]) {
                    const partnerData = users[partnerId] as ChatContact;
                     const myChats = await api.getMyChats();
                     const chatContact = myChats.find(c => c.id === partnerId);
                     setIsMuted(chatContact?.is_muted ?? false);

                    setPartner({ ...partnerData, isOnline: !partnerData.lastSeen });
                } else if (chatId === GLOBAL_CHAT_ID) {
                    setIsMuted(localStorage.getItem('global_chat_muted') === 'true');
                }
            }
        } catch (e) {
            setError(t('chat.loadError'));
        } finally {
            if (isInitial) setIsLoading(false);
            isFetchingMoreRef.current = false;
        }
    }, [chatId, currentUser, t]);
    
    useEffect(() => {
        resetState();
        fetchMessages(true);
    }, [chatId, fetchMessages, resetState]);

    const handleScroll = useCallback(() => {
        const container = chatContainerRef.current;
        if (container) {
            const { scrollTop, scrollHeight, clientHeight } = container;
            wasAtBottomRef.current = scrollHeight - scrollTop - clientHeight < 150;

            if (scrollTop < 50 && hasMore && !isFetchingMoreRef.current) {
                scrollStateRef.current = {
                    shouldPreserve: true,
                    oldScrollHeight: scrollHeight
                };
                fetchMessages(false);
            }
        }
    }, [hasMore, fetchMessages]);
    
    // Reworked scroll logic into a single robust effect
    useLayoutEffect(() => {
        const container = chatContainerRef.current;
        if (!container) return;

        if (scrollStateRef.current.shouldPreserve) {
            // This is for loading older messages, preserve position
            container.scrollTop += (container.scrollHeight - scrollStateRef.current.oldScrollHeight);
            scrollStateRef.current.shouldPreserve = false;
        } else if (wasAtBottomRef.current) {
            // This is for initial load or new messages when user was at the bottom
            messagesEndRef.current?.scrollIntoView({ behavior: hasScrolledInitially.current ? 'smooth' : 'auto' });
        }
        
        if (!hasScrolledInitially.current && messages.length > 0) {
            hasScrolledInitially.current = true;
        }
    }, [messages]);

    useEffect(() => {
        if (socket && chatId) {
            socket.emit('viewingChat', { chatId });
            return () => {
                socket.emit('stopViewingChat', { chatId });
            };
        }
    }, [socket, chatId]);

    useEffect(() => {
        if (!socket || !chatId) return;

        socket.emit('joinRoom', chatId);
        
        const handleNewMessage = (payload: Message & { sender?: User }) => {
            const { sender, ...msg } = payload;
            if (msg.chatId === chatId) {
                const container = chatContainerRef.current;
                if(container) {
                    const { scrollTop, scrollHeight, clientHeight } = container;
                    wasAtBottomRef.current = scrollHeight - scrollTop - clientHeight < 150;
                } else {
                    wasAtBottomRef.current = true;
                }

                // FIX: If the sender's data isn't in chatUsers, add it.
                // This prevents the UI from breaking when a new user (e.g., via Telegram reply) messages.
                if (sender) {
                     setChatUsers(prev => prev[sender.id] ? prev : { ...prev, [sender.id]: sender });
                }

                setMessages(prev => {
                    // This is the de-duplication logic.
                    if (prev.some(m => m.id === msg.id || (m.tempId && m.tempId === msg.tempId))) {
                        // If we find a temp message, replace it with the real one from the server.
                        return prev.map(m => m.tempId === msg.tempId ? msg : m);
                    }
                    return [...prev, msg];
                });
                 // CRITICAL FIX: Mark as read immediately if window is focused
                if (document.visibilityState === 'visible' && msg.senderId !== currentUser?.id) { 
                    socket.emit('markMessagesAsRead', { chatId });
                }
            }
        };

        const handleMessageEdited = (msg: { id: string, chatId: string, content: string, isEdited: boolean }) => {
            if (msg.chatId === chatId) {
                setMessages(prev => prev.map(m => m.id === msg.id ? { ...m, content: msg.content, isEdited: true } : m));
            }
        };
        
        const handleMessageReactionUpdated = (data